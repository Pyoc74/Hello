var n=0;

while(true){
    n=n+1;
    if(n>10){
        break;
    } else {
        document.write(n);
    }

}