
var player = 1;
// var player = 5;
// var player = 6;


switch (player) {
    case 1 :
        document.write(1);
        //...
        //...
        break;
    case 2 :
        document.write(2);
        //...
        //...   
        break;     
    case 3 :
    case 4 :
        document.write("3이나 4임");
        //...   
        //...   
        break;     
    case 5 :
        document.write(2);
        //...
        //...   
        break;
    default :
        document.write("디폴트 처리");
        //...
        //...         
        break;
}

// switch (player) {
//     case "가위": a = 1;
//         break;
//     case "바위": a = 2;
//         break;
//     case "보":  a = 3;
//         break;
// }
