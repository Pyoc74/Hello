
// switch 사용 없이 switch부분 이미지 출력코드를 한줄로 처리하기

document.write("<img src='dice6_" + (Math.floor(Math.random() * 6) + 1) + ".jpg'>");