// 문10	반복문	for	1~10 출력

// for(var i=1;i<=10;i=i+1){
//     document.write(i);
// }

// for(var i=1; i<=100; i=i+1){
//     document.write(i);
// }

// for(var i=1; i<=20; i=i+1){
//     document.write(i);
// }

// for(var i=1; i<=30; i=i+1){
//     document.write(i);
// }

// for(var i=1; i<=40; i=i+1){
//     document.write(i);
// }

// for(var i=1; i<=50; i=i+1){
//     document.write(i);
// }

// for(var i=1; i<=10; i=i+1){
//     document.write(i);
//     document.write("<hr>");
// }


// for(var i=1; i<=10; i=i+1){
//     document.write(i);
//     document.write("<br>");
// }

for(var i=1; i<=10; i=i+1){
    document.write(i);
    document.write("<br>");
}