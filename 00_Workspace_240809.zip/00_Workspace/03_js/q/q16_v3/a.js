// while문 사용. 1~10 출력


var i = 1;
while (i <= 10) {
    document.write(i);
    i = i + 1;
}


