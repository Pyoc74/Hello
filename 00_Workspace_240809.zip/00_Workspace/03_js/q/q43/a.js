// 문43	
// 1	아무 숫자 매개변수 하나를 받아 1을 더하여 리턴하는 함수 만들기
// 2	1을 호출하면서 매개변수에 100값을 넘기고 결과를 출력


function a(x){
    var c = x + 1;

    return c;
}

var y = a(100);

document.write(y);