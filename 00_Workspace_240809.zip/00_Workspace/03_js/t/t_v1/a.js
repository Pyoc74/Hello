//반복문//



for(var i=1; i<3; i=i+1) {

    document.write("고양이");
    document.write("멍멍이");

}

document.wrtite("토깽이");