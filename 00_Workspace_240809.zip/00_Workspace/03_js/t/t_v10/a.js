// i = i + 1;
//위 식의 단축버전
// i++;

var sum = 0;
for( var j = 1 ; j <= 3 ; j ++ ) {
    document.write("<hr>");
    for ( var i = 1 ; i <= 10 ; i++ ) {
        sum = sum + i ;
    }

    document.write("<hr>");

}
alert ( sum ) ; // 55 * 3 = 165