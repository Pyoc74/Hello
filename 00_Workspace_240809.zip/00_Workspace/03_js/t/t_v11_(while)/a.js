var sum = 0;

var i=1;

while (i <= 10) {
    sum=sum+i;
    i=i+1;
}
alert(sum)= 55;