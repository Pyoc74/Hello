

// function xx() {
//     document.write("고양이");
//     document.write("고양이");
//     document.write("고양이");
// }

// xx();
// xx();
// xx();


// ***************************************

function xx(x){
    for(var i=0; i<x; i=i+1){
        document.write("고양이");
    }
}

xx(3);
document.write("<hr>");
xx(100);

//*************************************** 

function xx(x,y) {
    for(var i=1; i<y; i=i+1){
        
    }
}