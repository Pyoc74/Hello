function br(){
    document.write("<br>");
}

function hr(){
    document.write("<hr>");
}

document.write("고양이");
br();
document.write("고양이");
hr();
document.write("고양이");
br();
document.write("고양이");
hr();
document.write("고양이");
br();
document.write("고양이");
hr();