// var userRpc = prompt("가위 / 바위 / 보 하쉴?");
// var comRpcNumber = Math.floor(Math.random()*3+1);
// var comRpcStr = "";

// if (comRpcNumber == 1){
//     comRpcStr = "가위";
// }
// if (comRpcNumber == 2){
//     comRpcStr = "바위";
// }
// if (comRpcNumber == 3){
//     comRpcStr = "보";
// }

// dw("유저:&nbsp"+userRpc);
// br();
// dw("컴퓨터:&nbsp"+comRpcStr);
// br();

// var winDrawLose = "";
// switch(userRpc){
//     case "가위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "무승부";
//                 break;
//             case "바위":
//                 winDrawLose = "패배";
//                 break;            
//             case "보":
//                 winDrawLose = "승리";
//                 break;
//             }
//             break;
//     case "바위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "승리";
//                 break;
//             case "바위":
//                 winDrawLose = "무승부";
//                 break;            
//             case "보":
//                 winDrawLose = "패배";
//                 break;
//             }
//             break;
//     case "보":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "패배";
//                 break;
//             case "바위":
//                 winDrawLose = "승리";
//                 break;            
//             case "보":
//                 winDrawLose = "무승부";
//                 break;
//             }
//             break;
// }

// dw(winDrawLose);

//****************************************************************
// var userRpc = prompt("가위 / 바위 / 보 게임 Let's Go~");
// var comRpcNumber = Math.floor(Math.random()*3+1);
// var comRpcStr = "";

// if (comRpcNumber == 1) { 
//     comRpcStr = "가위";
// }
// if (comRpcNumber == 2) { 
//     comRpcStr = "바위";
// }
// if (comRpcNumber == 3) { 
//     comRpcStr = "보";
// }

// dw("유저: "+userRpc);
// br();
// dw("컴퓨터: "+comRpcStr);
// br();

// var winDrawLose = "";
// switch(userRpc){
//     case "가위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "무승부";
//                 break;
//             case "바위":
//                 winDrawLose = "패배";
//                 break;
//             case "보":
//                 winDrawLose = "승리";
//                 break;
//         }
//         break;
//     case "바위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "승리";
//                 break;
//             case "바위":
//                 winDrawLose = "무승부";
//                 break;
//             case "보":
//                 winDrawLose = "패배";
//                 break;
//         }
//         break;
//     case "보":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "패배";
//                 break;
//             case "바위":
//                 winDrawLose = "승리";
//                 break;
//             case "보":
//                 winDrawLose = "무승부";
//                 break;
//         }
//         break;
// }

// dw(winDrawLose);


// var userRpc = prompt("가위 / 바위 / 보 게임 gogogo:");
// var comRpcNumber = Math.floor(Math.random()*3+1);
// var comRpcStr = ""; 
// if(comRpcNumber == 1){
//     comRpcStr = "가위";
// }
// if(comRpcNumber == 2){
//     comRpcStr = "바위";
// }
// if(comRpcNumber == 3){
//     comRpcStr = "보";
// }

// dw("유저:&nbsp&nbsp"+userRpc);
// br();
// dw("컴퓨터:&nbsp&nbsp"+comRpcStr);
// br();

// var winDrawLose = "";
// switch(userRpc){
//     case "가위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "무승부";
//                 break;
//             case "바위":
//                 winDrawLose = "패배";
//                 break;
//             case "보":
//                 winDrawLose = "승리";
//                 break;
//         }
//         break;
//     case "바위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "승리";
//                 break;
//             case "바위":
//                 winDrawLose = "무승부";
//                 break;
//             case "보":
//                 winDrawLose = "패배";
//                 break;
//         }
//         break;
//     case "보":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "패배";
//                 break;
//             case "바위":
//                 winDrawLose = "승리";
//                 break;
//             case "보":
//                 winDrawLose = "무승부";
//                 break;
//         }
//         break;
// }

// dw(winDrawLose);


// var userRpc = prompt("가위 / 바위 / 보 Game!");
// var comRpcNumber = Math.floor(Math.random()*3+1);
// var comRpcStr = "";
// if(comRpcNumber == 1) {
//     comRpcStr = "가위";
// }
// if(comRpcNumber == 2) {
//     comRpcStr = "바위";
// }
// if(comRpcNumber == 3) {
//     comRpcStr = "보";
// }

// dw("User:&nbsp&nbsp"+userRpc);
// br();
// dw("Com:&nbsp&nbsp"+comRpcStr);
// br();

// var winDrawLose = "";
// switch(userRpc){
//     case "가위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "무승부";
//                 break;
//             case "바위":
//                 winDrawLose = "패배";
//                 break;
//             case "보":
//                 winDrawLose = "승리";
//                 break;
//         }
//         break;
//     case "바위":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "승리";
//                 break;
//             case "바위":
//                 winDrawLose = "무승부";
//                 break;
//             case "보":
//                 winDrawLose = "패배";
//                 break;
//         }
//         break;
//     case "보":
//         switch(comRpcStr){
//             case "가위":
//                 winDrawLose = "패배";
//                 break;
//             case "바위":
//                 winDrawLose = "승리";
//                 break;
//             case "보":
//                 winDrawLose = "무승부";
//                 break;
//         }
//         break;
// }

// dw(winDrawLose);


var userRpc = prompt("가위 / 바위 / 보 Game!");
var comRpcNumber = Math.floor(Math.random()*3)+1;
var comRpcStr = "";
if(comRpcNumber == 1){
    comRpcStr = "가위";
}
if(comRpcNumber == 2){
    comRpcStr = "바위";
}
if(comRpcNumber == 3){
    comRpcStr = "보";
}

dw("User:&nbsp"+userRpc);
br();
dw("Com:&nbsp"+comRpcStr);
br();

var winDrawLose = "";
switch(userRpc){
    case "가위":
        switch(comRpcStr){
            case "가위":
                winDrawLose = "무승부";
                break;
            case "바위":
                winDrawLose = "패배";
                break;
            case "보":
                winDrawLose = "승리";
                break;
        }
        break;
    case "바위":
        switch(comRpcStr){
            case "가위":
                winDrawLose = "승리";
                break;
            case "바위":
                winDrawLose = "무승부";
                break;
            case "보":
                winDrawLose = "패배";
                break;
        }
        break;
    case "보":
        switch(comRpcStr){
            case "가위":
                winDrawLose = "패배";
                break;
            case "바위":
                winDrawLose = "승리";
                break;
            case "보":
                winDrawLose = "무승부";
                break;
        }
        break;
}
dw(winDrawLose);