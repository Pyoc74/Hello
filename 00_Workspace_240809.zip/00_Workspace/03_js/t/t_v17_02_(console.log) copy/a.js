
var a = 1;

console.log("========== a 값은? :"+a);

a = 100;

console.log("========== a 값은? :"+a);

a = 1000;

console.log("========== a 값은? :"+a);


function x(){  
    console.log("========== a 값은? :"+a);
    console.log("========== a 값은? :"+a);
    console.log("========== a 값은? :"+a);
    console.log("========== a 값은? :"+a);
    console.log("========== a 값은? :"+a);
}

x();

console.log("========== a 값은? :"+a);
console.log("========== a 값은? :"+a);
console.log("========== a 값은? :"+a);
console.log("========== a 값은? :"+a);
console.log("========== a 값은? :"+a);
