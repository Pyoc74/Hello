var season = [ '봄' , '여름' , '가을' , '겨울' ]; 

// alert(season[0]);

document.write(season[0]); //index는 0부터 시작(0-1-2-3-4...)