//   로또 01 ~                                     //
//   1. 컴퓨터가 1~45 수를 6개 뽑아서 출력          //
/////////////////////////////////////////////////////

// // 내 번호들
// var p1 = 1;
// var p2 = 2;
// var p3 = 3;
// var p4 = 4;
// var p5 = 5;
// var p6 = 6;

// 내 번호
var p1 = Math.floor(Math.random()*45)+1;
var p2 = Math.floor(Math.random()*45)+1;
var p3 = Math.floor(Math.random()*45)+1;
var p4 = Math.floor(Math.random()*45)+1;
var p5 = Math.floor(Math.random()*45)+1;
var p6 = Math.floor(Math.random()*45)+1;

// 컴 번호
var r1,r2,r3,r4,r5,r6;

// 앞선 번호들과 비교하여 중복된 번호가 나온 경우 다시 번호를 뽑게 하기
// (그렇게 해서 나온 번호도 또 검사를 계속 해야함)
r1 = Math.floor(Math.random()*45)+1;
dw(r1);
hr();

while(true){
    r2 = Math.floor(Math.random()*45)+1;
    if(r1!=r2){
        dw(r2);
        hr();
        break;
    }
}

while(true){
    r3 = Math.floor(Math.random()*45)+1;
    if(r3 != r1 && r3 != r2){
        dw(r3);
        hr();
        break;
    }
}

while(true){
    r4 = Math.floor(Math.random()*45)+1;
    if(r4 != r1 && r4 != r2 && r4 != r3){
        dw(r4);
        hr();
        break;
    }
}

while(true){
    r5 = Math.floor(Math.random()*45)+1;
    if(r5 != r1 && r5 != r2 && r5 != r3 && r5 != r4){
        dw(r5);
        hr();
        break;
    }
}

while(true){
    r6 = Math.floor(Math.random()*45)+1;
    if(r6 != r1 && r6 != r2 && r6 != r3 && r6 != r4 && r6 != r5){
        dw(r6);
        hr();
        break;
    }
}

// 일치한 갯수
var win = 0;
// p1
if(p1 == r1){
    win = win + 1;
}
if(p1 == r2){
    win = win + 1;
}
if(p1 == r3){
    win = win + 1;
}
if(p1 == r4){
    win = win + 1;
}
if(p1 == r5){
    win = win + 1;
}
if(p1 == r6){
    win = win + 1;
}
//p2
if(p2 == r1){
    win = win + 1;
}
if(p2 == r2){
    win = win + 1;
}
if(p2 == r3){
    win = win + 1;
}
if(p2 == r4){
    win = win + 1;
}
if(p2 == r5){
    win = win + 1;
}
if(p2 == r6){
    win = win + 1;
}
//p3
if(p3 == r1){
    win = win + 1;
}
if(p3 == r2){
    win = win + 1;
}
if(p3 == r3){
    win = win + 1;
}
if(p3 == r4){
    win = win + 1;
}
if(p3 == r5){
    win = win + 1;
}
if(p3 == r6){
    win = win + 1;
}
//p4
if(p4 == r1){
    win = win + 1;
}
if(p4 == r2){
    win = win + 1;
}
if(p4 == r3){
    win = win + 1;
}
if(p4 == r4){
    win = win + 1;
}
if(p4 == r5){
    win = win + 1;
}
if(p4 == r6){
    win = win + 1;
}
//p5
if(p5 == r1){
    win = win + 1;
}
if(p5 == r2){
    win = win + 1;
}
if(p5 == r3){
    win = win + 1;
}
if(p5 == r4){
    win = win + 1;
}
if(p5 == r5){
    win = win + 1;
}
if(p5 == r6){
    win = win + 1;
}
//p6
if(p6 == r1){
    win = win + 1;
}
if(p6 == r2){
    win = win + 1;
}
if(p6 == r3){
    win = win + 1;
}
if(p6 == r4){
    win = win + 1;
}
if(p6 == r5){
    win = win + 1;
}
if(p6 == r6){
    win = win + 1;
}

dw("win"+win);


// var p1 = 1;
// var p2 = 2;
// var p3 = 3;
// var p4 = 4;
// var p5 = 5;
// var p6 = 6;

// var r1 = Math.floor(Math.random()*45)+1;
// var r2 = Math.floor(Math.random()*45)+1;
// var r3 = Math.floor(Math.random()*45)+1;
// var r4 = Math.floor(Math.random()*45)+1;
// var r5 = Math.floor(Math.random()*45)+1;
// var r6 = Math.floor(Math.random()*45)+1;

// dw(r1);
// hr();
// dw(r2);
// hr();
// dw(r3);
// hr();
// dw(r4);
// hr();
// dw(r5);
// hr();
// dw(r6);
// hr();