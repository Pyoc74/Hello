//   로또 01 ~ 13                                   //
//   1. 컴퓨터가 1~45 수를 6개 뽑아서 출력          //
/////////////////////////////////////////////////////


// 내 번호
var p = [0,0,0,0,0,0];

p[0] = Math.floor(Math.random() * 45) + 1;
p[1] = Math.floor(Math.random() * 45) + 1;
p[2] = Math.floor(Math.random() * 45) + 1;
p[3] = Math.floor(Math.random() * 45) + 1;
p[4] = Math.floor(Math.random() * 45) + 1;
p[5] = Math.floor(Math.random() * 45) + 1;

dw(p[0]);
br();
dw(p[1]);
br();
dw(p[2]);
br();
dw(p[3]);
br();
dw(p[4]);
br();
dw(p[5]);
hr();

dw("[당첨번호]");
br();

// 컴 번호
var r = [0,0,0,0,0,0];

// 앞선 번호들과 비교하여 중복된 번호가 나온 경우 다시 번호를 뽑게 하기
// (그렇게 해서 나온 번호도 또 검사를 계속 해야함)
r[0] = Math.floor(Math.random() * 45) + 1;
dw(r[0]);
br();

while (true) {
    r[1] = Math.floor(Math.random() * 45) + 1;
    if (r[0] != r[1]) {
        dw(r[1]);
        br();
        break;
    }
}

while (true) {
    r[2] = Math.floor(Math.random() * 45) + 1;
    if (r[2] != r[0] && r[2] != r[1]) {
        dw(r[2]);
        br();
        break;
    }
}

while (true) {
    r[3] = Math.floor(Math.random() * 45) + 1;
    if (r[3] != r[0] && r[3] != r[1] && r[3] != r[2]) {
        dw(r[3]);
        br();
        break;
    }
}

while (true) {
    r[4] = Math.floor(Math.random() * 45) + 1;
    if (r[4] != r[0] && r[4] != r[1] && r[4] != r[2] && r[4] != r[3]) {
        dw(r[4]);
        br();
        break;
    }
}

while (true) {
    r[5] = Math.floor(Math.random() * 45) + 1;
    if (r[5] != r[0] && r[5] != r[1] && r[5] != r[2] && r[5] != r[3] && r[5] != r[2]) {
        dw(r[5]);
        br();
        break;
    }
}

// 보너스 번호
var b = 0; 
while(true){
    b=Math.floor(Math.random()*45)+1;
    if(b != r[0] && b != r[1] && b != r[2] && b != r[3] && b != r[4] && b != r[5]){
        dw("보너스 번호: "+b);
        dw("<br>");
        break;
    }
} 

// 일치한 갯수
var win = 0;

// 일치하는 갯수 작업을 반복문과 배열로 처리
for (var i = 0; i <= 5; i = i + 1) {
    for (var j = 0; j <= 5; j = j + 1) {
        if (p[i] == r[j]) {
            win = win + 1;
        }
    }
}

// 몇개 맞췄는지 출력
// dw("win"+win);
dw("맞은 번호 갯수: "+win+"<br>");

// 몇개 맞췄는지에 따라 등수 출력하기
var str = "";
switch(win){
    case 0:
    case 1:
    case 2:
        str = "꽝!!! 다음 기회에😥";
        break;
    case 3:
        str = "5등에 당첨되셨습니다🥮";
        break; 
    case 4:
        str = "4등에 당첨되셨습니다💵";
        break; 
    case 5:
        str = "3등에 당첨되셨습니다💸";
        // 2등 처리
        for(var i=0; i<6; i=i+1){
            if(b==p[i]){
                srt = "2등에 당첨되셨습니다💰"
            }
        }
        break; 
    case 6:
        str = "1등!!! 아이스크림 하나만 사주세요🍦";
        break; 
}
dw(str);