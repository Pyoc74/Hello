
function add(x,y){
    var sum = x + y;
    return sum;
}

var yy = add(1,2);
document.write(yy);