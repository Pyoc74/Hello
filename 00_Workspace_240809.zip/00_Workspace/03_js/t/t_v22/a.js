// 변수범위의 이해

var star = "손"

function a() {
    
    var b = 1;  // b는 지역변수
    
    alert(b);  // 1 출력 가능
    // alert(star); // "손" 출력
}
function x() {
    
    var b = 2;  

    alert(b); 

}

a();
x();
alert(b);
