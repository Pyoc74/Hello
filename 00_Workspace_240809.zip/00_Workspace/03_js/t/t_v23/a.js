

function Cat(){
/* 속성 또는 프로퍼티들 (아래 다섯가지의 '멤버변수') */
    this.name = "";  // 이름
    this.age = 0;    // 나이
    this.weight = 0; // 몸무게
    this.family = "";    // 종류 (ex. 코리안숏헤어, 페르시아고양이)
    this.color = "black";     // 털색
}

// 1. Cat 클래스 객체 생성하기
new Cat();
// 2. 변수 kitty를 선언하고 여기에 위의(1번 문제의) Cat 클래스 객체 생성문 넣기 
var kitty = new Cat();
// 3. 이 클래스형 변수 kitty가 가진 name 변수에 "야옹이"를 넣기
kitty.age= 10;

// 4. 위 고양이 이름을 출력하기
document.write(kitty.age);