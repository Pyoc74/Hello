// function Cat(){	
// 	/* 속성 또는 프로퍼티들 */
// 	this.name = "";  // 이름
// 	this.age = 0;    // 나이
// 	this.weight = 0; // 몸무게
// 	this.family = "";    // 종류 (ex. 코리안숏헤어, 페르시아고양이)
// 	this.color = "";     // 털색
// }


// // 1. Cat 클래스 객체를 생성하기.
// new Cat();

// // 2. 변수 kitty 를 선언하고 여기에 위의(1번문제의) Cat 클래스 객체 생성문을 넣기(대입하기).
// var kitty = new Cat();



// // 3.이 클래스형 변수 kitty 가 가진 name 변수에 "야옹이" 를 넣기( "야옹이" 라고 이름 지어주기)
// kitty.name = "야옹이";
// kitty.age = 7;
// kitty.weight = 100;
// kitty.family = "페르시아";
// kitty.color = "삼색이";


// // 4.위 고양이 이름을 출력하기
// document.write("이름: "+kitty.name);  br();
// document.write("나이: "+kitty.age); br();
// document.write("무게: "+kitty.weight);  br();
// document.write("종: "+kitty.family);  br();
// document.write("털색: "+kitty.color);  br();

// br();br();


// // 문46의 키티에 나머지 값들도 넣어주시고 각각 다 출력
// var doohan = new Cat();
// doohan.name = "두한";
// doohan.age = 3;
// doohan.weight = 10;
// doohan.family = "종로";
// doohan.color = "흰색";

// document.write("이름: "+doohan.name);  br();
// document.write("나이: "+doohan.age); br();
// document.write("무게: "+doohan.weight);  br();
// document.write("종: "+doohan.family);  br();
// document.write("털색: "+doohan.color);  br();


// br();br();

// if(kitty.age > doohan.age){
//     document.write("키티가 형님");
// }else if(kitty.age < doohan.age){
//     document.write("두한이가 형님");
// }else{
//     document.write("동갑내기");
// }
    

///////////////////////////////////////////////////////

function Cat(){
    this.name = "";
    this.age = 0;
    this.wight = 0;
    this.family = "";
    this.color = "";

    this.crying = function() {
        dw("야옹~");
    }
}

new Cat();

var kitty = new Cat();
kitty.name = "야옹이";
kitty.age = 4;
kitty.weight = 150;
kitty.family = "샴";
kitty.color = "오렌지";

dw(kitty.name); br();
dw(kitty.age); br();
dw(kitty.weight); br();
dw(kitty.family); br();
dw(kitty.color); br();
br();br();


var nyang = new Cat();
nyang.name = "흑묘"
nyang.age = 4;
nyang.weight = 150;
nyang.family = "35사단";
nyang.color = "검정";

dw(nyang.name); br();
dw(nyang.age); br();
dw(nyang.weight); br();
dw(nyang.family); br();
dw(nyang.color); br();
br();br();


if(kitty.age > nyang.age){
    dw("야옹이가 형님이올시다.");
}else if(kitty.age < nyang.age){
    dw("흑묘가 형님이올시다.");
}else{
    dw("동갑이올시다.");
}
br();br();

kitty.crying();
nyang.crying();
br();br();

///////////////////////////////////////////

