

function Mob(){
    this.name;
    this.hp;
    this.attack;

    this.info = function(){
        hr();
        dw("["+this.name+"]["+this.hp+"][atk:"+this.attack+"]")
    }

}