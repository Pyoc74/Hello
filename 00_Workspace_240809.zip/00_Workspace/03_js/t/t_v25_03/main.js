// /**********************************************************************
// rpg (v0.3.0)
// ***********************************************************************

// function Monster(name,hp,attack){
//     this.name = name;
//     this.hp = hp;
//     this.attack = attack; 

//     this.info = function(){
//         dw("이름: "+this.name+" / HP: "+this.hp+" / 공격력: "+this.attack);
//     }
// }

// function Character(){
//     this.name;
//     this.hp;
//     this.attack;
    
//     this.info = function(){
//         dw("이름: "+this.name+" / HP: "+this.hp+" / 공격력: "+this.attack);
//     }
// }

// var orc = new Monster("오크",100,10);

// var elf = new Character();
// elf.name = "갑수르";
// elf.hp = 200;
// elf.attack = 20;


// orc.info();
// br();br();
// elf.info();

// hr();
// dw("전투시작💥");
// hr();

// var elf_attack = r(elf.attack);
// var orc_attack = r(orc.attack);

// hr();
// dw("Player 데미지: "+elf.attack);
// hr();
// dw("Mob 데미지 "+orc.attack);
// hr();

// elf.hp = elf.hp - orc_attack;
// orc.hp = orc.hp - elf_attack;

// orc.info();
// br();br();
// elf.info();

function Mob(name,race,hp,attack){
    this.name = name;
    this.race = race;
    this.hp = hp;
    this.attack = attack;

    this.info = function(){
        dw("이름: "+this.name+" / 종족: "+this.race+" / HP: "+this.hp+" / 공격력: "+this.attack);
    }
}

function Character(name,race,hp,attack){
    this.name = name;
    this.race = race;
    this.hp = hp;
    this.attack = attack;

    this.info = function(){
        dw("이름: "+this.name+" / 종족: "+this.race+" / HP: "+this.hp+" / 공격력: "+this.attack);
    }
}

var goblin = new Mob("그린뉘크","고블린",150,15);
var elf = new Character("아론디르","엘프",300,20);

goblin.info();
br();
br();
elf.info();


br();
br();
hr();
dw("💥전투시작💥");
hr();
br();

var elf_attack = r(elf.attack);
var goblin_attack = r(goblin.attack);

hr();
dw("엘프의 데미지: "+elf_attack+"🏹");
hr();
dw("고블린의 데미지: "+goblin_attack+"🪓");
hr();

elf.hp=elf.hp-goblin_attack;
goblin.hp=goblin.hp-elf_attack;

goblin.info();
br();br();
elf.info();