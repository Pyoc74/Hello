// /**********************************************************************
// rpg (v0.4.0)
// ***********************************************************************

function Mob(name,hp,attack){
    this.name = name;
    this.hp = hp;
    this.max_hp = hp;
    this.attack = attack;

    this.info = function(){
        dw("["+this.name+"("+this.hp+ " / "+this.max_hp+")]");
    }
}

function Character(name,hp,attack){
    this.name = name;
    this.hp = hp;
    this.max_hp = hp;
    this.attack = attack;

    this.info = function(){
        dw("["+this.name+"("+this.hp+ " / "+this.max_hp+")]");
    }
}

var goblin = new Mob("고블린씨",150,15);
var elf = new Character("아론디르",300,15);

goblin.info();
br();
br();
elf.info();


br();
br();
hr();
dw("💥전투시작💥");
hr();
br();

var elf_attack = r(elf.attack);
var goblin_attack = r(goblin.attack);

hr();
dw("엘프의 데미지: "+elf_attack+"🏹");
hr();
dw("고블린의 데미지: "+goblin_attack+"🪓");
hr();

elf.hp=elf.hp-goblin_attack;
goblin.hp=goblin.hp-elf_attack;

goblin.info();
br();br();
elf.info();