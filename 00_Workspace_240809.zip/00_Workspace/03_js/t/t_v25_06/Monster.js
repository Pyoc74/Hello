function Monster(name,hp,attack){
    this.name = name;
    this.currentHp = hp;
    this.maxHp = hp;
    this.attack = attack;

    this.info = function(){
        dw("["+this.name+"("+this.currentHp+ "/"+this.maxHp+")]");
    }
}