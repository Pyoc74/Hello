// /**********************************************************************
// rpg (v0.6.0)
// ***********************************************************************

var goblin = new Monster("고블린씨",100,8);
var elf = new Character("아론디르",120,7);

// displayCharactersInfo();
goblin.info();
br();
dw("&nbsp&nbsp&nbspVS&nbsp&nbsp&nbsp")
br();
elf.info();


//전투 처리
//전투 시작
hr();
dw("💥전투시작💥");
hr();

// 전투 무한루프
var loop = true;
while(loop){
    loop = procBattleTurn();
}

function procBattleTurn(){
    
    var monsterDamage = getRandomAttackValue(goblin.attack);
    var playerDamage = getRandomAttackValue(elf.attack);
    
    goblin.currentHp = goblin.currentHp - playerDamage;
    dw(elf.name + "이(가) " +goblin.name + "에게 데미지를 "+playerDamage +" 입혔습니다.<br>");
    elf.currentHp = elf.currentHp - monsterDamage;
    dw(goblin.name + "이(가) " + elf.name + "에게 데미지를 "+monsterDamage +" 입혔습니다.<br>");
    
    
    displayCharactersInfo();
    //todo hp 검사하기
    if(elf.currentHp<=0||goblin.currentHp<=0){
        return false;
    } else {
        return true;
    }
}

function getRandomAttackValue(attack){
    attack = attack + 1;
    var random = Math.floor(Math.random()*attack);
    return random;
}

function displayCharactersInfo(){
    hr();
    elf.info();
    goblin.info();
    hr();
}