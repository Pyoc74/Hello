var box;''

var a;

a=1;

var b;

b=2;

// box = "고양이";
box = a+b;


document.write(box);

// document.write("고양이");