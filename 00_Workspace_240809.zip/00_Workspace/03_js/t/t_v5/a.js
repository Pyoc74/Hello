var a = 1;
var b = 2;

if(a > b) {

  alert ( "가" );

} else {

   alert ( "나" );
}