// 증가식이란?
// for ( 초기값 ; 조건 ; 증가식 ) { 실행할 명령 }

document.write("x");

for ( var i=1 ; i <= 4 ; i=i+1 ) {
    // 실행할 명령
    document.write("고양이");
    document.write("<hr>");

}

document.write("x");