var box;


box = "고양이"+1;

box = "고양이" + "1";

box = "고양이1";