// 반복문	고양이 이미지	를 5번 출력하세요
for(var i=1 ; i <= 20 ; i = i + 1 ){
    document.write("<img src='cat.jpg'>");
}