// 문11	조건문	if	숫자 변수 하나 선언 후 100 을 부여		이 변수값이 1  보다 크면		"크다"	라고 팝업 출력

// var a=100;
// if(a>1){
//     alert("크다");
// }

// var a=100;
// if(a>1){
//     alert("크다");
// }

// var a=5;
// if(a>10){
//     alert("크다");
// } else {
//     alert("작다");
// }

// var a=100;
// if(a>1){
//     alert("크다");
// }

// var a=1;
// if(a<100){
//     alert("작다");
// }

// var a=100;
// if(a>1){
//     alert("크다");
// }

var a=25;
if(a>50){
    alert("크다");
} else {
    alert("작다");
}

var a=51;
if(a<=50) {
    alert("작다");
} else {
    alert("크다");
}

var a=333;
if(a>=100) {
    alert("크다");
} else { 
    alert("작다");
}