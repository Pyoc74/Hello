// 문13	조건문	if - else if - else	prompt 함수를 이용하여 숫자 값을 하나 입력 받기			
// 			이 값이 100 보다 크면		100 보다 큽니다	라고 팝업 출력
// 			이 값이 100 보다 작으면		100 보다 작습니다	라고 팝업 출력
// 			그 외에는		100 입니다.	라고 팝업 출력

// var s = prompt("값을 입력하세요 :");
// if(s > 100){
//     alert("100보다큼");
// } else if(s <100)    {
//     alert("100보다 작음");
// } else {
//     alert("100임");
// }

// var s = prompt("값을 입력하세요 :");
// if(s > 100){
//     alert("100보다큼");
// } else if(s<100) {
//     alert("100보다 작음");
// } else {
//     alert("100임");
// }

// var s = prompt("값을 적아라! : ");
// if(s > 10){
//     alert("10보다 큼");
// } else if(s<10) {
//     alert("10보다 작음");
// } else {
//     alert("10임");
// }

// var s = prompt("맞춰볼게~");
// if(s>100){
//     alert("100보다 큼");
// } else if(s<100){
//     alert("100보다 작음");
// } else {
//     alert("100임");
// }

var s = prompt("맞춰볼게~");
if(s>100){
    alert("100보다 큼");
} else if(s<100){
    alert("100보다 작음");
} else {
    alert("100임");
}