//함수


//변수

//전역변수. global. 인싸변수.
//지역변수. local. 아싸변수

/* ****************************
var a ;
var t ;
var n ;
var s ;

//함수선언(만들기)
function xx(){
    a = "2살";
    t = "시고르자브종";
    n = "야옹이";
    
    word_plus();
    alert(s);

}

function word_plus(){
    s = a + t + n;
}

//함수  사용하기. 실행한다. 호출한다.

xx();
***************************** */


var a ;
var t ;
var n ;
var s ;

function xx(){
    a = "2살"
    t = "페르시안"
    n = "고양이"
    word_plus();
    alert(s);
}

function word_plus(){
    s=a+t+n;
}

xx();