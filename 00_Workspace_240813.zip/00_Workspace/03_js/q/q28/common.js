function hr(){
    document.write("<hr>");
}


function br(){
    document.write("<br>");
}