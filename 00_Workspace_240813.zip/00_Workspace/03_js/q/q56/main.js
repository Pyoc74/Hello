// /**********************************************************************
// rpg (v0.7.0)
// ***********************************************************************

// - 전투 종료 처리(종료메세지 출력, 경험치 획득)
// - 케릭터 클래스에 현재 경험치, 다음 레벨업에 필요한 경험치 두 변수를 추가하기. (현재 경험치는 초기값 0. 필요 경험치는 초기값 300 주기)
//   (레벨업 경험치 기획은 현재 미정. 300값 하드코딩.)
// - 몬스터를 잡고 받은 경험치 획득 처리는 플레이어의 현재 경험치에 100을 추가해주기
// - 플레이어 간략 정보 표시에 현재 경험치/다음 레벨업 필요 경험치 표시 추가 ex. [엠피스(70/100)](exp: 100/300)
// (레벨업 경험치 기획은 현재 미정. 300값 하드코딩.)
// - 전투 종료 후 얻은 경험치를 확인하기 위해 플레이어 info 함수 한번 호출하기
// - 적 전투력 높혀서 플레이어도 잘 죽는지 확인


var dragon = new Monster("드래곤",100,20);

var elf = new Character();
elf.name = "성모";
elf.hp = 200;
elf.max_hp = 200;
elf.attack = 20;
elf.exp = 0;
elf.next_exp = 300;

elf.info();
dragon.info();

hr();
dw("전투시작");
hr();


function proc_battle(){
	var elf_attack = r(elf.attack);
	var dragon_attack = r(dragon.attack);
	
	hr();
	dw("🏹플레이어 데미지:"+elf_attack);
	hr();
	dw("🪓몬스터 데미지:"+dragon_attack);
	hr();
	
	elf.hp = elf.hp - dragon_attack;		// 1~10 랜덤 뎀
	dragon.hp = dragon.hp - elf_attack;	
	
	elf.info();
	dragon.info();
}



while(true){
	proc_battle();

	if(elf.hp <= 0 || dragon.hp <= 0){
		break;
	}
}


dw("전투종료"); br();
dw("100 경험치를 얻었습니다.");
elf.exp = elf.exp + 100;

hr();hr();

elf.info();

