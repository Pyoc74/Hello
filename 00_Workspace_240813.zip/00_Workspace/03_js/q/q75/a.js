// - 문75
// - 로그인 입력 태그들을 하나의 div 로 묶고 보더, 높이, 폭, 배경, border-radius 등을 넣기				
// - input 태그에 placeholder 속성을 이용하여 힌트 삽입.		
// - 로그인 입력 박스를 (div) 전체 화면의 가로, 세로 중앙위치에 정렬하기			
// - 박스에 그림자도 추가

function login(){
    var tagId = document.getElementById("id");
    var tagPw = document.getElementById("pw");

    var id = tagId.value;
    var pw = tagPw.value;

    console.log(id);
    console.log(pw);

    if(id == "cat" && pw == "1234"){
        alert("로그인 성공");
    }else{
        alert("로그인 실패");
    }
}