function xxx(){
    var popup = document.getElementById("popup");
    // popup.style.display = "none";
    popup.style.background = "pink";
    popup.style.width = "100px";
    popup.style.height = "100px";
    popup.style.transitionProperty = "background, width, height";
    popup.style.transitionDuration = "1s";
}
