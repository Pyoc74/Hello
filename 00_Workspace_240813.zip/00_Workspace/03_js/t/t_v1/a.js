
console.log("###여기가 1차###");
var tagX;

// tagX = xxx;

// console.log(tagX);

// tagX.innerHTML = "고양이";
// tagX.innerHTML = "<img>";

function a(){
    console.log("### 6 ###");
}


window.onload = function(){
    console.log("### 4 ###");
    tagX = document.getElementById("x");
    console.log("### 5 ###");
    
    a();

    console.log("### 7 ###");
}

console.log("### 2 ###");
console.log("### 3 ###");

function y(){
    console.log("### 8 ###");
    console.log("### 9 ###");
}