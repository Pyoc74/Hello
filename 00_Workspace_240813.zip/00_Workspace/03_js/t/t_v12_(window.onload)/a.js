var x = 10;

window.onload = function () {

    var t = document.getElementById("a");

    t.innerHTML = "고양이";
}