
function r(max){
    var x = Math.floor(Math.random()*max)+1
    // document.write(x);
    
    return x;
}

//검 데미지 1~100

var shortSwordRandomDamage = r(100);
document.write(shortSwordRandomDamage);
document.write("<hr>");

var longSwordRandomDamage = r(500);
document.write(longSwordRandomDamage);