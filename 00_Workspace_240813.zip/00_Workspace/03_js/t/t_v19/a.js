var a = [1, 2, 3];

for(var i=0;i<3;i=i+1){
    document.write(a[i]);
}
