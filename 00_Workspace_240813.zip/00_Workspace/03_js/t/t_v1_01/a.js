// var tagId;


// window.onload = function(){
//     tagId = document.getElementById("input_id");

// }


function login(){
    var tagId = document.getElementById("input_id");

    var stringId = tagId.value;
    console.log(stringId);
    alert(stringId);

}







// console.log("###여기가 1차###");
// var tagX;


// function a(){
//     console.log("### 6 ###");
// }


// window.onload = function(){
//     console.log("### 4 ###");
//     tagX = document.getElementById("x");
//     console.log("### 5 ###");
    
//     a();

//     console.log("### 7 ###");
// }

// console.log("### 2 ###");
// console.log("### 3 ###");

// function y(){
//     console.log("### 8 ###");
//     console.log("### 9 ###");
// }