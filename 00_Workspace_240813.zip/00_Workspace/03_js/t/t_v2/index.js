// console.log("헬로월드");

var tagZ;

window.onload = function(){
    tagZ = document.getElementById("z");
    
    tagZ.addEventListener("click", handleClick);
}

function(){
    console.log("x버튼 클릭");
}