package com.project.rpc;

public class Xxx {
	public static void main(String[] args) {
		Rps r = new Rps();
		r.run();
	}
}