package com.project.rpc_02;

public class Xxx {
	public static void main(String[] args) {
		Rps rps = new Rps();
		rps.run();
	}
}