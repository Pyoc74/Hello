package com.test;

public class Xxx {
	public static void main(String[] arge) {
		
//		var a = [1,2,3];
//		var a = new Array();
		
		int n[] = new int[2];
		System.out.println(n[1]);

		int x[] = {1,2,3};
		System.out.println(x[1]);
		
		String s[] = {"개","고양이","소","토끼"};
		System.out.println(s[3]);
		
		
//		String r = 4>2 ? "야용" : "멍";
//		System.out.println(r);
		
	}
}
