package com.sde.helloworld;

public class Hello {

	
	
	public static void main(String[] args) {
	
		// JS에서의 consol.log랑 동일한 역할
		System.out.println("헬로월드!");
	
//		var a = 1;
		int a = 1;
		System.out.println(a+10);
		
		
		String s = "개";
		System.out.println(s);
		
		
		for(int i=0;i<3;i=i+1) {
			if(i==1) {
				continue;
			}
		}
		System.out.println(1);
	}
}

