package com.project.lotto;

public class Lotto {

	void run() {
		System.out.println("===로또 프로그램===");
	
		
//		int r1 = (int)(Math.random()*45+1);
//		int r2 = (int)(Math.random()*45+1);
//		int r3 = (int)(Math.random()*45+1);
//		int r4 = (int)(Math.random()*45+1);
//		int r5 = (int)(Math.random()*45+1);
//		int r6 = (int)(Math.random()*45+1);
		
		int r[] = {0,0,0,0,0,0};
		// 첫번재 번호
		r[0] = (int)(Math.random()*45+1);
//		r[1] = (int)(Math.random()*45+1);
//		r[2] = (int)(Math.random()*45+1);
//		r[3] = (int)(Math.random()*45+1);
//		r[4] = (int)(Math.random()*45+1);
//		r[5] = (int)(Math.random()*45+1);

		// 두번재 번호
		while(true) {
			r[1] = (int)(Math.random()*45+1);
			if(r[0]!=r[1]) {
				break;
			}
		}
		// 세번재 번호
		while(true) {
			r[2] = (int)(Math.random()*45+1);
			if(r[0]!=r[2] && r[1]!=r[2]) {
				break;
			}
		}
		// 네번재 번호
		while(true) {
			r[3] = (int)(Math.random()*45+1);
			if(r[0]!=r[3] && r[1]!=r[3] && r[2]!=r[3]) {
				break;
			}
		}
		// 다섯번재 번호
		while(true) {
			r[4] = (int)(Math.random()*45+1);
			if(r[0]!=r[4] && r[1]!=r[4] && r[2]!=r[4] && r[3]!=r[4]) {
				break;
			}
		}
		// 여섯번재 번호
		while(true) {
			r[5] = (int)(Math.random()*45+1);
			if(r[0]!=r[5] && r[1]!=r[5] && r[2]!=r[5] && r[3]!=r[5] && r[4]!=r[5]) {
				break;
			}
		}
		
		
		int p[] = {1,2,3,4,5,6};
		
		System.out.print("유저번호:");
		for (int i = 0; i < p.length; i++) {
			System.out.print(p[i] + " ");
		}
		System.out.println();
		System.out.print("추첨번호:");
		for (int i = 0; i < p.length; i++) {
			System.out.print(r[i] + " ");
		
		
		}
		// 맞춘개수 처리
		int win = 0;
		for(int i=0;i<6;i=i+1) {
			for(int j=0;j<6;j=j+1) {
				if(p[i] == r[j]) {
					win=win+1;
				}
			}
		}
		System.out.println();
		System.out.println("✨맞춘갯수:"+win+"개");
}
}

///////////////////////////////

//	public void run() {
////		int x[] = {1,2};
//		//로또 로직
//		int p[] = {1,2,3,4,5,6};
//		int r[] = new int[6];
//		
//		r[0] = (int)(Math.random()*45+1);
//		// 중복체크: 2번째번호
//		while(true) {
//			r[1] = (int)(Math.random()*45+1);
//			if(r[0]!=r[1]) {
//				break;
//			}
//		}
//		// 중복체크: 3번째번호
//		while(true) {
//			r[2] = (int)(Math.random()*45+1);
//			if(r[0]!=r[2] && r[1]!=r[2]) {
//				break;
//			}
//		}
//		// 중복체크: 4번째번호
//		while(true) {
//			r[3] = (int)(Math.random()*45+1);
//			if(r[0]!=r[3] && r[1]!=r[3] && r[2]!=r[3]) {
//				break;
//			}
//		}
//		// 중복체크: 5번째번호
//		while(true) {
//			r[4] = (int)(Math.random()*45+1);
//			if(r[0]!=r[4] && r[1]!=r[4] && r[2]!=r[4] && r[3]!=r[4]) {
//				break;
//			}
//		}
//		// 중복체크: 6번째번호
//		while(true) {
//			r[5] = (int)(Math.random()*45+1);
//			if(r[0]!=r[5] && r[1]!=r[5] && r[2]!=r[5] && r[3]!=r[5] && r[4]!=r[5]) {
//				break;
//			}
//		}
//		
//		System.out.println("=== 당첨 번호 ===");
//		System.out.print(r[0]+" ");
//		System.out.print(r[1]+" ");
//		System.out.print(r[2]+" ");
//		System.out.print(r[3]+" ");
//		System.out.print(r[4]+" ");
//		System.out.print(r[5]+" ");
//		
//		int win = 0;
//		for(int i=0;i<6;i=i+1) {
//			for(int j=0;j<6;j=j+1) {
//				if(p[i] == r[j]) {
//					win=win+1;
//				}
//			}
//		}
//		
//		System.out.println("맞춘갯수:"+win);
//	}
//}