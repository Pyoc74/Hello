package com.project.rpc_02_pr;

import java.util.Scanner;

public class Rps {
	void run()  {
		Scanner sc = new Scanner(System.in);
		int r = 0;
		String cmd = "";
		String result = "";
		
		xx:
		while(true) {
			System.out.println("가위바위보 gogo! (종료 X) :");
			cmd = sc.next();
			r = (int)(Math.random()*3)+1;
			switch(cmd) {
			case "가위":
				switch(r) {
				case 1: 
					result = "비김";
					break;
				case 2: 
					result = "패배";
					break;
				case 3: 
					result = "승리";
					break;
				}
				break;
				
			case "바위":
				switch(r) {
				case 1: 
					result = "승리";
					break;
				case 2: 
					result = "비김";
					break;
				case 3: 
					result = "패배";
					break;
				}
				break;
				
			case "보":
				switch(r) {
				case 1: 
					result = "패배";
					break;
				case 2: 
					result = "승리";
					break;
				case 3: 
					result = "비김";
					break;
				}
				
				break;
			case "x":
				break xx;
			}
			System.out.println(result);
		}
		System.out.println("프로그램 종료");
	}
}
