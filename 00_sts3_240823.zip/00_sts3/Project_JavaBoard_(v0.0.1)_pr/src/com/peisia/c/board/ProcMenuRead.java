package com.peisia.c.board;

import com.peisia.util.Cw;

public class ProcMenuRead {
	static void run() {
		Cw.wn("읽기임");
	}
}
