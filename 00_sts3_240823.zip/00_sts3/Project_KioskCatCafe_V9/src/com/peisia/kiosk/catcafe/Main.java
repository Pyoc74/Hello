package com.peisia.kiosk.catcafe;

public class Main {

	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}


// * java 11 버전에서 호환되게끔 압축파일 다운 후 설정 수정 필요