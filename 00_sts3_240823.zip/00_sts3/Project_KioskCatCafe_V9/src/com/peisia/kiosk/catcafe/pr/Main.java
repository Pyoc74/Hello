// v7
package com.peisia.kiosk.catcafe.pr;

public class Main {
	
	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}







