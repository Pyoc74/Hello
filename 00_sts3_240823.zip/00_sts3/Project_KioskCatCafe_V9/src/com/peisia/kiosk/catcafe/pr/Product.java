package com.peisia.kiosk.catcafe.pr;

public class Product {
	String name;
	int price;

	// 오버로딩: 함수이름 같지만 중복 추가하는 것.
	
	//생성자함수 - 그중에 매개변수 2개짜리
//	Product(int price, String name){
//		this.name = name;
//		this.price = price;
//	}
//	Product(String name, int price){
//		this.name = name;
//		this.price = price;
//	}
//	Product(String name){
//		this.name = name;
//	}
//	// '빈생성자' 없으면 에러발생!
//	Product(){
//		
//	}
	
	Product(String xx, int yy){
		name = xx;
		price = yy;
	}
	
	void info() {
		System.out.println("(상품명:"+name+" 가격:"+price+"원)");
	}
}
