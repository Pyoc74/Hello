package com.project.extends02;

public class Character extends GameObj {
	
	// String name;
	int hp;
	
	public Character(String name,int grade,int hp) {
		super(name,grade);	//super 함수는 무조건 맨 처음에 와야함. 룰임.
		this.hp = hp;
		 
	}
	
	void info() {
		System.out.println("이름:" + name + " 등급:" + grade + " (고양이는 귀여우니까 hp도 출력:" + hp + ")");
	}
}
