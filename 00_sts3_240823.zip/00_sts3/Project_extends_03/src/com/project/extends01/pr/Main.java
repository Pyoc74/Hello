package com.project.extends01.pr;

import java.util.ArrayList;

import com.peisia.c.util.Color;
import com.peisia.c.util.So;

public class Main {

	public static void main(String[] args) {
		Character c = new Character("고양이", 3, 1000);
		Sword s = new Sword("단검", 2, 100, 50, 70);
		Sword l = new Sword("짱검", 3, 150, 100, 70);

		((GameObj) c).name = "토끼";

		GameObj g1 = (GameObj) s;
		GameObj g2 = (GameObj) c;

		GameObj g3 = s;
		GameObj g4 = c;

		ArrayList<GameObj> gf = new ArrayList<>();
		gf.add(g3);
		gf.add(g4);

		Sword shortSword = (Sword) g3;
		shortSword.slash();

		if (g3 instanceof Sword) {
			Color.green("원래는 검이었던 것");
		}
		if (g4 instanceof Character) {
			Color.red("원래는 캐릭이었던 것");
		}

		ArrayList<GameObj> gs = new ArrayList<>();
		gs.add(c);
		gs.add(s);
		gs.add(l);
		for (GameObj o : gs) {
			So.ln(o.name);
			if (o instanceof Sword) {
				System.out.println(o.name + "의 공격력은 " + ((Sword) o).attack);
			}
			if (o instanceof Character) {
				System.out.println(o.name + "의 체력은 " + ((Character) o).hp);
			}
		}
		int n = 1 + ((Sword) gs.get(2)).attack;
		So.ln("공격력" + n);

		GameObj xx = c;

		System.out.println(System.identityHashCode(c));
		System.out.println(System.identityHashCode(xx));

		Item x = new Item();

		Item z = new Sword();

		Sword xxx = new Sword();

		Item yyy = xxx;

		Sword sss = (Sword) yyy;

	}
}
