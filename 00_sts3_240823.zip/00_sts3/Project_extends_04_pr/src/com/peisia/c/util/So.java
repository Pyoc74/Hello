
package com.peisia.c.util;

public class So {
	public static void ln(String s) {
	System.out.println(s);	
	}
	public static void ln(int n) {
	}
	public static void p(String s) {
		System.out.println(s);
	}
}
