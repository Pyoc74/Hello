package com.project.extends01;

public class Sword extends Item {
	int attack;

}
