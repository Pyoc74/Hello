package com.project.extends01.pr;

public class Item extends GameObj {
	int weight;
	int 수명;
}
