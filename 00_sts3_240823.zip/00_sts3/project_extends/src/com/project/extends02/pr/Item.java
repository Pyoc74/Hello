package com.project.extends02.pr;

public class Item extends GameObj {
	int weight;
	int 수명;
}
