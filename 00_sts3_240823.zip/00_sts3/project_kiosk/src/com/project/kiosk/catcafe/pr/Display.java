package com.project.kiosk.catcafe.pr;

import com.project.c.util.So;

public class Display {

	String x = "x";
	
	final static String DOT = "☠";
	
	public static void line() {
		for(int i=0; i<32; i=i+1) {
			So.p(DOT);
		}
		So.ln("");
	}
	
	public static void title() {
		line();
		So.ln("************** 캐앳 카페   ***************");
		line();
	}
}