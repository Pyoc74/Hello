// v4 -> v5
package com.project.kiosk.catcafe.pr;

public class Main {
	
	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}
