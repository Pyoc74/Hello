package com.project.lotto.pr.v3;

public class Lotto {
	
	void run() {
		System.out.println("===로또 프로그램===");
		
		int r[] = {0,0,0,0,0,0};
		//첫번째
		r[0] = (int)(Math.random()*45+1);
		
		//두번째
		while(true) {
			r[1] = (int)(Math.random()*45+1);
			if(r[0]!=r[1]) {
				break;
			}
		}
		//세번째
		while(true) {
			r[2] = (int)(Math.random()*45+1);
			if(r[0]!=r[2] && r[1]!=r[2]) {
				break;
			}
		}
		//네번째
		while(true) {
			r[3] = (int)(Math.random()*45+1);
			if(r[0]!=r[3] && r[1]!=r[3] && r[2]!=r[3]) {
				break;
			}
		}
		//다섯번째
		while(true) {
			r[4] = (int)(Math.random()*45+1);
			if(r[0]!=r[4] && r[1]!=r[4] && r[2]!=r[4] && r[3]!=r[4]) {
				break;
			}
		}
		//여섯번째
		while(true) {
			r[5] = (int)(Math.random()*45+1);
			if(r[0]!=r[5] && r[1]!=r[5] && r[2]!=r[5] && r[3]!=r[5] && r[4]!=r[5]) {
				break;
			}
		}
		
		int p[] = {1,2,3,4,5,6};
		
		System.out.print("유저번호:");
		for (int i=0; i<p.length; i=i+1) {
			System.out.print(p[i] + " ");
		}
		System.out.println();
		System.out.print("당첨번호:");
		for (int i=0; i<p.length; i=i+1) {
			System.out.print(r[i] + " ");
		}
		
		//맞춘개수
		int win = 0;
		for(int i=0; i<6; i++) {
			for(int j=0; j<6; j++) {
				if(p[i] == r[j]) { 
					win=win+1;
				}
			}
		}
		System.out.println();
		System.out.println("맞춘갯수:"+win+"개");
	}
}
		
		
	
	