package com.project.lotto.pr.v4;

public class Lotto {
	void run() {
		System.out.println("===로또 프로그램 연습ver4.===");
		 int r[] = {0,0,0,0,0,0};
		 
		 r[0] = (int)(Math.random()*45+1);
		 
		 while(true) {
			 r[1] = (int)(Math.random()*45+1);
			 if(r[0]!=r[1]) {
				 break;
			 }
		 }
		 while(true) {
			 r[2] = (int)(Math.random()*45+1);
			 if(r[0]!=r[2] && r[1]!=r[2]) {
				 break;
			 }
		 }
		 while(true) {
			 r[3] = (int)(Math.random()*45+1);
			 if(r[0]!=r[3] && r[1]!=r[3] && r[2]!=r[3]) {
				 break;
			 }
		 }
		 while(true) {
			 r[4] = (int)(Math.random()*45+1);
			 if(r[0]!=r[4] && r[1]!=r[4] && r[2]!=r[4] && r[3]!=r[4]) {
				 break;
			 }
		 }
		 while(true) {
			 r[5] = (int)(Math.random()*45+1);
			 if(r[0]!=r[5] && r[1]!=r[5] && r[2]!=r[5] && r[3]!=r[5] && r[4]!=r[5]) {
				 break;
			 }
		 }
		 
		 int p[] = {5,15,25,35,45,7};
		 
		 System.out.print("유저번호:");
		 for(int i = 0; i<p.length; i++) {
			 System.out.print(p[i] + " ");
		 }
		 System.out.println();
		 System.out.print("당첨번호:");
		 for (int i = 0; i<p.length; i++) {
			 System.out.print(r[i] + " ");
			 
		 }
		 int win = 0;
		 for(int i=0;i<6;i=i+1) {
			 for(int j=0;j<6;j=j+1) {
				 if(p[i] == r[j]) {
					 win=win+1;
				 }
			 }
		 }
		 System.out.println();
		 System.out.println("🛩맞춘갯수"+win+"개");
	}
}
		
		
	
	