package com.project.rpc_02_pr;

public class Xxx {
	public static void main(String[] args) {
		Rps rps = new Rps();
		rps.run();
	
}
}