package com.peisia.c.board;

import com.peisia.util.Cw;

public class ProcMenuDel {
	static void run() {
		Cw.wn("삭제임");
	}

}
