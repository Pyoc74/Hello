package com.peisia.kiosk.catcafe;

//자동임포트 단축키: ctrl+shift+o(영문자O)
public class Kiosk {
	
}