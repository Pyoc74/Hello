package com.peisia.kiosk.catcafe.product;

public class Figure {

	

}
