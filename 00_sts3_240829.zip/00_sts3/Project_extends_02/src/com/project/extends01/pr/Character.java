package com.project.extends01.pr;

public class Character extends GameObj {
	int hp;
	
	public Character(String name,int grade,int hp) {
		super(name, grade);
		this.hp = hp;
		
	}

	void info() {
		System.out.println("이름:" + name + " 등급:" + grade + "(귀여움이 세상을 지배한다:" +"[hp]"+ hp + ")");
	}
}
