package com.project.extends01.pr;

import java.util.ArrayList;
import com.peisia.c.util.So;

public class Main {

		public static void main(String[] args) {
			Character c = new Character("고양이",3,1000);
			Sword s = new Sword("단검",2,100,50,70);
			Sword l = new Sword("짱검",3,150,100,70);
			
			ArrayList<GameObj> gs = new ArrayList<>();
			gs.add(c);
			gs.add(s);
			gs.add(l);
			for(GameObj o : gs) {
				o.info();
			}
			GameObj gg = (GameObj) s;
			
			
			if(gg instanceof Sword) {
				So.ln("얘 원래 검임");
			}
		}

	
}

