package com.peisia.c.sang4;

import com.peisia.c.util.So;

public class Elf extends Monster  {

	@Override
	void attack(Player p) {
		attack = 7;
		So.ln(0);
	}

}
