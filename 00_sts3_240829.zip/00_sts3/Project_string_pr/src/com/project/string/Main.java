package com.project.string;

public class Main {

	public static void main(String[] args) {
		
		String cat = "고양이";
		
		String cat2 = "고양이";
		
		if(cat == cat2) {
			System.out.println("같음");
		} else {
			System.out.println("다름");
		}
		
		String dog = new String("개");
		String dog2 = new String("개");
		System.out.println(dog);
		System.out.println(dog2);
		if(dog == dog2)	{
			System.out.println("같음");
		} else {
			System.out.println("다름"); //*같은 '개'이지만 주소가 같은지만 비교하기 때문
		}
		
		if(dog.equals(dog2)) {
			System.out.println("문자열 같음"); //*equals 함수를 통해 문자열 비교
		} else {
			System.out.println("문자열 다름");
		}
	}
}

