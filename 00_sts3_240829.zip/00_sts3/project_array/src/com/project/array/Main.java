package com.project.array;

public class Main {
	void run() {

		int x[] = {1,2};
		
		System.out.print(x[0]);
		System.out.print(x[1]);

		String s[] = {"개","고양이"};
		System.out.println(s[1]);
	}
}
