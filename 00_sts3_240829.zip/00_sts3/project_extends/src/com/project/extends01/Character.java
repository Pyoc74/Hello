package com.project.extends01;

public class Character extends GameObj{
//	String name;
	int hp;
	int attack;
	
}
