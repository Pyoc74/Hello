package com.project.extends01;

public class Item extends GameObj {
//	String name;
	
	int weight;
	int 수명;
}
