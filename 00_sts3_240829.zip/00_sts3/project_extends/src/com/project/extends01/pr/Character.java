package com.project.extends01.pr;

public class Character extends GameObj{
	int hp;
	int attack;
}
