package com.project.extends01.pr;

public class GameObj {
	String name;
	
	void info() {
		System.out.println("이름: "+name);
	}
}
