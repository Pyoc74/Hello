package com.project.extends01.pr;

public class Main {
	
	public static void main(String[] args) {
		Character elf = new Character();
		elf.name = "곽두팔";
		elf.hp = 1;
		elf.info();
	
		Item book = new Item();
		book.weight = 100;
		book.name = "깔깔유머집";
		book.info();
		
		Sword shortSword = new Sword();
		shortSword.name = "장미칼";
		shortSword.attack = 100;
		shortSword.weight = 10;
		shortSword.info();

	}
}

