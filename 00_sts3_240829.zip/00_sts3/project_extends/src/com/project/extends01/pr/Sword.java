package com.project.extends01.pr;

	public class Sword extends Item {
		int attack;
	}



