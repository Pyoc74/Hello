package com.project.extends02.pr;

public class Character extends GameObj {
	int hp;
	int attack;
}
