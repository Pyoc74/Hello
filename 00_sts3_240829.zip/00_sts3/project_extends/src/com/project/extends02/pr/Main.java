package com.project.extends02.pr;

public class Main {
	
	public static void main(String[] args) {
		Character elf = new Character();
		elf.name = "손종수";
		elf.hp = 1;
		elf.info();
		
		Item book = new Item();
		book.weight = 100;
		book.name = "무서운게 딱좋아";
		book.info();
		
		Sword shortSword = new Sword();
		shortSword.name = "단단검";
		shortSword.attack = 100;
		shortSword.weight = 10;
		shortSword.info();
	

	}
}

