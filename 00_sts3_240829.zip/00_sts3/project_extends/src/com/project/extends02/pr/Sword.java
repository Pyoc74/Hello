package com.project.extends02.pr;

	public class Sword extends Item {
		int attack;
	}



