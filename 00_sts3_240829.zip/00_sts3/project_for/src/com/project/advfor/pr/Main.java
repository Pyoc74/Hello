package com.project.advfor.pr;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<String> animals = new ArrayList<>();
		animals.add("고양이");
		animals.add("토끼");
		animals.add("강아지");
		animals.add("송아지");
		animals.add("침팬지");
		
		// *기존 for문 방식
		for(int i=0;i<animals.size();i=i+1) {
			System.out.println(animals.get(i));
		}
		
	System.out.println("");
		
		for (String x : animals) {
			System.out.println(x);
		}

	System.out.println("");
		
		int a[] = { 5, 4, 3, 2, 1, 0 };
		for (int n : a) {
			System.out.println(n);
		}

	System.out.println("");
		
		Cat cat1 = new Cat("민식", 7);
		Cat cat2 = new Cat("준수", 4);
		Cat cat3 = new Cat("정환", 5);
		ArrayList<Cat> cats = new ArrayList<>();
		cats.add(cat1);
		cats.add(cat2);
		cats.add(cat3);
		for (Cat x : cats) {
			System.out.println("냥이름: " + x.name);
			System.out.println("냥나이: " + x.age);
		}

	}

}
