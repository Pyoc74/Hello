package com.project.rpg.pr;

public class Main {

	public static void main(String[] args) {
//		Character elf = new Character();
		Character player = new Character("곽두팔",100,20,"노움");
		
//		Monster orc = new Monster("오크족장",50,10);
//		Monster orc = new Monster("오크족장",50,10);
		player.info();
//		orc.info(); 

	}

}
