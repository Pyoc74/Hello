package com.project.rpg.pr02;

public class Main {

	public static void main(String[] args) {
		Character player = new Character("윤정수",100,20,"엘프");
		
		player.info();
	}
}