package com.peisia.c.laligasqaud.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.peisia.c.laligasquad.display.Display;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;


// V0.0.5 = case 5번 주제 수정 및 case 6번 추가
// 		    

		
public class ProcSquad {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	void run() {
		Display.showTitle();
		dbInit();
		//dbExecuteQuery("select * from laliga_squad where p_club = 'barcelona'");
		//dbExecuteQuery("select * from laliga_squad");
		//dbExecuteUpdate("insert into laliga_squad (p_club,p_number,p_name,p_birth,p_position,p_height,p_foot,p_country,p_market_value,currency) values ('Girona',1,'Juan Carlos','1988-01-20','골키퍼',185,'오른발','스페인',30,'만 유로')");

		loop:
		while(true) {
			Display.showMainMenu();
			String cmd = Ci.r("명령번호 입력: ");
			switch(cmd) {
			case "1":
				System.out.println("=============================");
				System.out.println("========== 클럽 리스트 ========");
				try { 
					// 1. 중복되지 않은 클럽 리스트 출력
                    Set<String> clubSet = new HashSet<>();  // 중복을 허용하지 않는 Set 사용
                    result = st.executeQuery("SELECT DISTINCT p_club FROM laliga_squad");
                    while (result.next()) {
                        String club = result.getString("p_club");
                        clubSet.add(club);  // 중복을 제거한 클럽 이름을 저장
                    }
					
                    // Set에 저장된 클럽 목록을 출력
                    for (String club : clubSet) {
                        System.out.println("클럽: " + club);
                    }
                    
					// 2. 사용자에게 클럽 선택 요청
                    String selectedClub = Ci.rl("확인할 클럽 이름을 입력해주세요: ");
                    
                    // 3. 선택된 클럽의 선수 정보 출력
                    String query = String.format("SELECT * FROM laliga_squad WHERE p_club = '%s'", selectedClub);
                    result = st.executeQuery(query);
                    System.out.println("========== 선택된 클럽 선수 리스트 ==========");
                    
                    while(result.next()) {
						String club = result.getString("p_club");
						String backNo = result.getString("p_number");
						String name = result.getString("p_name");
						String position = result.getString("p_position");
						System.out.println(club+" "+backNo+" "+name+" "+position);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "2":	// 선수정보 확인
				String checkPlayer = Ci.rl("확인할 선수 이름을 입력해주세요:");
				String sql2 = "select * from laliga_squad where p_name ='"+ checkPlayer + "'";
				try {
					result = st.executeQuery(sql2);
					result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
					String club = result.getString("p_club");	
					String backNo = result.getString("p_number");
					String name = result.getString("p_name");
					String birth = result.getString("p_birth");
					String position = result.getString("p_position");
					String height = result.getString("p_height");
					String foot = result.getString("p_foot");
					String country= result.getString("p_country");
					String marketValue= result.getString("p_market_value");
					System.out.println(club+" / "+backNo+" / "+name+" / "+birth+" / "+position+" / "+height+"cm / "+foot+" / "+country+" / "+marketValue+"만 유로");
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "3":	// 선수명단 추가
				String club = Ci.rl("소속 클럽을 입력해주세요: ");
				String backNo = Ci.r("등번호를 입력해주세요: ");
				String name = Ci.rl("선수 이름을 입력해주세요: ");
				String birth = Ci.r("출생정보를 입력해주세요: ");
				String position = Ci.r("포지션을 입력해주세요: ");
				String height = Ci.r("신장 높이를 입력해주세요: ");
				String foot = Ci.r("주발을 입력해주세요: ");
				String country = Ci.r("국적을 입력해주세요: ");
				String marketValue = Ci.r("시장가치를 입력해주세요: ");
				
				String x = String.format(
						"insert into laliga_squad (p_club,p_number,p_name,p_birth,p_position,p_height,p_foot,p_country,p_market_value,currency) "
								+ "values ('%s','%s','%s','%s','%s','%s','%s','%s','%s','만 유로');"
								,club,backNo,name,birth,position,height,foot,country,marketValue) ;
				dbExecuteUpdate(x);
				System.out.println(x);
				break;
			case "4":	// 명단삭제
				String delclub = Ci.rl("삭제할 선수의 클럽을 입력해주세요(1단계): ");
				String delbackno = Ci.r("삭제할 선수의 등번호를 입력해주세요(2단계): ");
				
				String sql = String.format("delete from laliga_squad where p_club = '%s' and p_number = '%s'",delclub,delbackno);
				System.out.println(sql);
				
				dbExecuteUpdate(sql);
				break;
			case "5":	// 구단별 선수 시장가치 분포
				Cw.wn("조회할 시장가치 범위를 선택해주세요(만 유로):");
				Cw.wn("1) 0 이상 ~ 100 미만");
			    Cw.wn("2) 100 이상 ~ 1000 미만");
			    Cw.wn("3) 1000 이상 ~ 3000 미만");
			    Cw.wn("4) 3000 이상 ~ 6000 미만");
			    Cw.wn("5) 6000 이상 ~ 10000 미만");
			    Cw.wn("6) 10000 이상");
			    
			    String rangeOption = Ci.r("번호 입력: ");
			    String rangeQuery = "";

			    switch (rangeOption) {
			        case "1":
			            rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 0 AND p_market_value < 100";
			            break;
			        case "2":
			            rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 100 AND p_market_value < 1000";
			            break;
			        case "3":
			            rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 1000 AND p_market_value < 3000";
			            break;
			        case "4":
			            rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 3000 AND p_market_value < 6000";
			            break;
			        case "5":
			            rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 6000 AND p_market_value < 10000";
			            break;
			        case "6":
			            rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 10000";
			            break;
			        default:
			            System.out.println("잘못된 입력입니다. 다시 시도해주세요.");
			            continue;
			    }
			    
			    try {
			        result = st.executeQuery(rangeQuery);
			        System.out.println("========== 선택된 시장가치 범위 선수 리스트 ==========");
			        
			        // 팀별 인원 수를 저장할 Map
			        Map<String, Integer> teamCountMap = new HashMap<>();
			        
			        while (result.next()) {
			            String clubV = result.getString("p_club");
			            String backNoV = result.getString("p_number");
			            String nameV = result.getString("p_name");
			            String birthV = result.getString("p_birth");
			            String positionV = result.getString("p_position");
			            String marketValueV = result.getString("p_market_value");
			            System.out.println(clubV + " / " + backNoV + " / "+ nameV + " / "  + birthV + " / " + positionV + " / " + marketValueV + "만 유로");
			            
			         // 팀별 인원 수 계산
			            teamCountMap.put(clubV, teamCountMap.getOrDefault(clubV, 0) + 1);
			        }
			        
			        // 팀별 인원 수 출력
			        System.out.println("========== 팀별 인원 수 ==========");
			        for (Map.Entry<String, Integer> entry : teamCountMap.entrySet()) {
			            System.out.println(entry.getKey() + ": " + entry.getValue() + "명");
			        }
			    } catch (Exception e) {
			        e.printStackTrace();
			    }
				break;
			case "6":	// 구단별 선수 시장가치 총합
			    try {
			        // SQL 쿼리: 각 구단별로 시장가치의 합계를 계산
			        String sumQuery = "SELECT p_club, SUM(p_market_value) AS total_value FROM laliga_squad GROUP BY p_club";
			        result = st.executeQuery(sumQuery);

			        System.out.println("========== 구단별 선수 시장가치 총합 ==========");

			        while (result.next()) {
			            String clubName = result.getString("p_club");
			            int totalValue = result.getInt("total_value"); // 시장가치 합계를 정수로 가져옵니다.

			            // '억'과 '만' 단위를 계산
			            int valueInBillion = totalValue / 10000;  // 억 단위
			            int valueInMillion = totalValue % 10000;  // 나머지 만 단위

			            String formattedValue;
			            if (valueInBillion > 0) {
			                formattedValue = valueInBillion + "억 " + valueInMillion + "만 유로";
			            } else {
			                formattedValue = valueInMillion + "만 유로";
			            }

			            System.out.println(clubName + ": " + formattedValue);
			        }
			    } catch (Exception e) {
			        e.printStackTrace();
			    }
				break;
			case "e":	// 종료
				System.out.println("라리가 스쿼드 종료☜(ﾟヮﾟ☜)");
				break loop;
			}
		}
	}

	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState " + e.getSQLState());
		}
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
			while (result.next()) {
				String name = result.getString("p_name");
				System.out.println(name);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("⚽처리된 명단 수:"+resultCount);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
