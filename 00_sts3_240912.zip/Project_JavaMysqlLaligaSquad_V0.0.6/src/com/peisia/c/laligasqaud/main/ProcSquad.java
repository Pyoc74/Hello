package com.peisia.c.laligasqaud.main;

import com.peisia.c.laligasquad.display.Display;
import com.peisia.c.laligasquad.operations.AddPlayer;
import com.peisia.c.laligasquad.operations.CheckPlayerInfo;
import com.peisia.c.laligasquad.operations.DeletePlayer;
import com.peisia.c.laligasquad.operations.MarketValueDistribution;
import com.peisia.c.laligasquad.operations.MarketValueSum;
import com.peisia.c.laligasquad.operations.ShowClubList;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Db;


// V0.0.6 = Db클래스 생성 및 각 기능별 클래스로 구분
// 		    

		
public class ProcSquad {

    void run() {
        Display.showTitle();
        Db.dbInit();

        loop:
        while (true) {
            Display.showMainMenu();
            String cmd = Ci.r("명령번호 입력: ");
            switch (cmd) {
                case "1":	//클럽 리스트
                    new ShowClubList().execute();
                    break;
                case "2":	//선수정보
                    new CheckPlayerInfo().execute();
                    break;
                case "3":	//명단 추가
                    new AddPlayer().execute();
                    break;
                case "4":	//명단 삭제
                    new DeletePlayer().execute();
                    break;
                case "5":	//선수 시장가치
                    new MarketValueDistribution().execute();
                    break;
                case "6":	//팀별 선수 시장가치 총합
                    new MarketValueSum().execute();
                    break;
                case "e":
                    System.out.println("라리가 스쿼드 종료☜(ﾟヮﾟ☜)");
                    break loop;
                default:
                    System.out.println("잘못된 명령입니다. 다시 시도해주세요.");
                    break;
            }
        }
    }
}
