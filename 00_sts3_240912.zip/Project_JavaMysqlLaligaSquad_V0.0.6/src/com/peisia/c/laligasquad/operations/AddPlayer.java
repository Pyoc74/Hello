package com.peisia.c.laligasquad.operations;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Db;

public class AddPlayer {
    public void execute() {
        String club = Ci.rl("소속 클럽을 입력해주세요: ");
        String backNo = Ci.r("등번호를 입력해주세요: ");
        String name = Ci.rl("선수 이름을 입력해주세요: ");
        String birth = Ci.r("출생정보를 입력해주세요: ");
        String position = Ci.r("포지션을 입력해주세요: ");
        String height = Ci.r("신장 높이를 입력해주세요: ");
        String foot = Ci.r("주발을 입력해주세요: ");
        String country = Ci.r("국적을 입력해주세요: ");
        String marketValue = Ci.r("시장가치를 입력해주세요: ");

        String x = String.format(
            "insert into laliga_squad (p_club, p_number, p_name, p_birth, p_position, p_height, p_foot, p_country, p_market_value, currency) " +
            "values ('%s','%s','%s','%s','%s','%s','%s','%s','%s','만 유로');",
            club, backNo, name, birth, position, height, foot, country, marketValue
        );
        Db.dbExecuteUpdate(x);
        System.out.println(x);
    }
}
