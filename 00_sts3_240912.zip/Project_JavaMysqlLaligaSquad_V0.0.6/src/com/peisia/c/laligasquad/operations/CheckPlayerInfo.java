package com.peisia.c.laligasquad.operations;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Db;

public class CheckPlayerInfo {
    public void execute() {
        String checkPlayer = Ci.rl("확인할 선수 이름을 입력해주세요:");
        String sql2 = "select * from laliga_squad where p_name ='" + checkPlayer + "'";
        try {
            Db.result = Db.st.executeQuery(sql2);
            Db.result.next(); // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
            String club = Db.result.getString("p_club");
            String backNo = Db.result.getString("p_number");
            String name = Db.result.getString("p_name");
            String birth = Db.result.getString("p_birth");
            String position = Db.result.getString("p_position");
            String height = Db.result.getString("p_height");
            String foot = Db.result.getString("p_foot");
            String country = Db.result.getString("p_country");
            String marketValue = Db.result.getString("p_market_value");
            System.out.println(club + " / " + backNo + " / " + name + " / " + birth + " / " + position + " / " + height + "cm / " + foot + " / " + country + " / " + marketValue + "만 유로");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
