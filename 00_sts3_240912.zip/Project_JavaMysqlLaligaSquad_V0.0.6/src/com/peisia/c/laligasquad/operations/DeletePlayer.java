package com.peisia.c.laligasquad.operations;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Db;

public class DeletePlayer {
    public void execute() {
        String delclub = Ci.rl("삭제할 선수의 클럽을 입력해주세요(1단계): ");
        String delbackno = Ci.r("삭제할 선수의 등번호를 입력해주세요(2단계): ");
        String sql = String.format("delete from laliga_squad where p_club = '%s' and p_number = '%s'", delclub, delbackno);
        System.out.println(sql);
        Db.dbExecuteUpdate(sql);
    }
}
