package com.peisia.c.laligasquad.operations;

import com.peisia.c.util.Db;

public class MarketValueSum {
    public void execute() {
        try {
            String sumQuery = "SELECT p_club, SUM(p_market_value) AS total_value FROM laliga_squad GROUP BY p_club";
            Db.result = Db.st.executeQuery(sumQuery);

            System.out.println("========== 구단별 선수 시장가치 총합 ==========");

            while (Db.result.next()) {
                String clubName = Db.result.getString("p_club");
                int totalValue = Db.result.getInt("total_value");

                int valueInBillion = totalValue / 10000;
                int valueInMillion = totalValue % 10000;

                String formattedValue;
                if (valueInBillion > 0) {
                    formattedValue = valueInBillion + "억 " + valueInMillion + "만 유로";
                } else {
                    formattedValue = valueInMillion + "만 유로";
                }

                System.out.println(clubName + ": " + formattedValue);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
