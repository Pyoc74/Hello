package com.peisia.c.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Db {
	static public Connection con = null;
	static public Statement st = null;
	static public ResultSet result = null;
	
	static public void dbInit() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			Db.st = Db.con.createStatement();
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState " + e.getSQLState());
		}
	}
	////////////
	static public void dbExecuteUpdate(String query) {
		//로그찍기
		Cw.wn("전송할sql"+query);
		try {
			int resultCount = st.executeUpdate(query);
			Cw.wn("⚽처리된 행 수:"+resultCount);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	////////////
	static public void dbExecuteQuery(String query) {
		try {
			Db.result = Db.st.executeQuery(query);
			while (Db.result.next()) {
				String name = Db.result.getString("p_name");
				System.out.println(name);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
}
