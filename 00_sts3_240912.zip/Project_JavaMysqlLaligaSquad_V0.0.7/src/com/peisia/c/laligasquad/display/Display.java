package com.peisia.c.laligasquad.display;

import com.peisia.c.util.Cw;

public class Display {
	static private String TITLE_BAR = "☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️☀️"; 
	static private String TITLE 	= "☀️☀️☀️☀️☀️☀️☀️☀️☀️☀☀     라리가 스쿼드     ☀☀️☀️☀️☀☀️☀️☀️☀️☀️☀"; 
	
	static private String MAIN_MENU_BAR = "============================================================================================";
	static private String MAIN_MENU	 	= "[1]클럽 리스트 [2]선수정보 [3]명단추가 [4]명단삭제 [5]선수 시장가치 분포 [6]구단별 선수 시장가치 총합  [e]종료";
	
	static public void showTitle() {
		System.out.println(TITLE_BAR);
		System.out.println(TITLE);
		System.out.println(TITLE_BAR);
	}
	
	static public void showMainMenu() {
		System.out.println(MAIN_MENU_BAR);
		System.out.println(MAIN_MENU);
		System.out.println(MAIN_MENU_BAR);
		
	}
	
	public static void replyBar() {
		Cw.wn("================= 댓글 리스트 ==================");
	}	
}
