package com.peisia.c.laligasquad.operations;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class CheckPlayerInfo {
	public void execute() {
		String checkPlayer = Ci.rl("확인할 선수 이름을 입력해주세요:");
		String sql2 = "select * from laliga_squad where p_name ='" + checkPlayer + "'";
		try {
			Db.result = Db.st.executeQuery(sql2);
			if (Db.result.next()) { // 결과가 있는지 확인
				int playerId = Db.result.getInt("id"); // 고유한 ID를 가져옴
				String club = Db.result.getString("p_club");
				String backNo = Db.result.getString("p_number");
				String name = Db.result.getString("p_name");
				String birth = Db.result.getString("p_birth");
				String position = Db.result.getString("p_position");
				String height = Db.result.getString("p_height");
				String foot = Db.result.getString("p_foot");
				String country = Db.result.getString("p_country");
				String marketValue = Db.result.getString("p_market_value");
				System.out.println(club + " / " + backNo + " / " + name + " / " + birth + " / " + position + " / "
						+ height + "cm / " + foot + " / " + country + " / " + marketValue + "만 유로");

				// 댓글 리스트 출력 처리
				// PlayerReply.list(Integer.parseInt(checkPlayer));

				PlayerReply.list(playerId); // 고유 ID를 사용하여 댓글 조회

				loop: while (true) { // 명령 입력 받게 하기. 나가기, 댓글쓰기
					String cmd = Ci.r("명령[x:나가기,r:댓글쓰기]");
					switch (cmd) {
					case "x":
						break loop;
					case "r":
						// 댓글 쓰기
						PlayerReply.write(playerId); // 고유 ID를 사용하여 댓글 작성
                        break;
					default:
						Cw.wn("장난x");
					}
				}
			} else {
				Cw.wn("선수를 찾을 수 없습니다.");
			}
			// // //
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
