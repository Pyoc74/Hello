package com.peisia.c.laligasquad.operations;

import java.sql.SQLException;

import com.peisia.c.laligasquad.display.Display;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class PlayerReply {
	/*
	 * 댓글 리스트 출력하는 함수
	 */
	static public void list(int oriNo) {
		Display.replyBar();
		String sql = "select * from laliga_squad where p_reply_ori="+oriNo;
		try {
			Cw.wn("전송한sql문:"+sql);
			Db.result = Db.st.executeQuery(sql);
			while(Db.result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String p_reply_text = Db.result.getString("p_reply_text");
				Cw.wn("* "+p_reply_text);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	/*
	 * 댓글 작성 함수
	 */
	static public void write(int p_reply_ori) {
		String p_reply_text = Ci.rl("댓글입력: ");
		Db.dbExecuteUpdate("insert into laliga_squad (datetime,p_reply_ori,p_reply_text) values(now(),"+p_reply_ori+",'"+p_reply_text+"')");
	}
}
