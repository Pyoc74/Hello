package com.peisia.c.laligasqaud.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main {
	public static void main(String[] args) {
		ProcSquad procSquad = new ProcSquad();
		procSquad.run();
	}
	
//	public static void main(String[] args) {
//		initDb();
//		dbRun();
//	}
//	
//	static private void initDb() {
//		try {
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			System.out.println("잘연결됨");
//		} catch (ClassNotFoundException e1) {
//			e1.printStackTrace();
//		}
//	}
//
//	static private void dbRun() {
//		try {
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
//			java.sql.Statement st = con.createStatement();
//			ResultSet result = st.executeQuery("select * from laliga_squad where p_club = 'Barcelona'");
//			//ResultSet result = st.executeQuery("select * from laliga_squad where p_number = 1");
//			while (result.next()) {
//				String name = result.getString("p_name");
//				System.out.println(name);
//			}
//		} catch (SQLException e) {
//			System.out.println("SQLException: " + e.getMessage());
//			System.out.println("SQLState: " + e.getMessage());
//		}
//	}
}
