package com.peisia.c.laligasqaud.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProcSquad {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	void run() {
		dbInit();
		//dbExecuteQuery("select * from laliga_squad where p_club = 'barcelona'");
		dbExecuteQuery("select * from laliga_squad");
	}

	
	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState " + e.getSQLState());
		}
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
			while (result.next()) {
				String name = result.getString("p_name");
				System.out.println(name);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	

}
