package com.peisia.c.laligasqaud.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

// V0.0.1 = 'dbExecuteUpdate'로 Squad에 명단 추가 삽입

public class ProcSquad {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	void run() {
		dbInit();
		dbExecuteQuery("select * from laliga_squad where p_club = 'barcelona'");
		//dbExecuteQuery("select * from laliga_squad");
		dbExecuteUpdate("insert into laliga_squad (p_club,p_number,p_name,p_birth,p_position,p_height,p_foot,p_country,p_market_value,currency) values ('Girona',1,'Juan Carlos','1988-01-20','골키퍼',185,'오른발','스페인',30,'만 유로')");
	}

	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState " + e.getSQLState());
		}
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
			while (result.next()) {
				String name = result.getString("p_name");
				System.out.println(name);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("추가된 행 수:"+resultCount);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
