package com.peisia.c.laligasqaud.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.peisia.c.laligasquad.display.Display;
import com.peisia.c.util.Ci;


// V0.0.3 = Display 클래스 생성, 목차 생성, 3번)명단 추가기능, 4번)삭제기능

		
public class ProcSquad {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	void run() {
		Display.showTitle();
		Display.showMainMenu();
		dbInit();
		//dbExecuteQuery("select * from laliga_squad where p_club = 'barcelona'");
		//dbExecuteQuery("select * from laliga_squad");
		//dbExecuteUpdate("insert into laliga_squad (p_club,p_number,p_name,p_birth,p_position,p_height,p_foot,p_country,p_market_value,currency) values ('Girona',1,'Juan Carlos','1988-01-20','골키퍼',185,'오른발','스페인',30,'만 유로')");

		loop:
		while(true) {
			String cmd = Ci.r("명령번호 입력: ");
			switch(cmd) {
			case "1":
				break;
			case "2":
				break;
			case "3":	// 선수명단 추가
				String club = Ci.rl("소속 클럽을 입력해주세요: ");
				String backno = Ci.r("등번호를 입력해주세요: ");
				String name = Ci.rl("선수 이름을 입력해주세요: ");
				String birth = Ci.r("출생정보를 입력해주세요: ");
				String position = Ci.r("포지션을 입력해주세요: ");
				String height = Ci.r("신장 높이를 입력해주세요: ");
				String foot = Ci.r("주발을 입력해주세요: ");
				String country = Ci.r("국적을 입력해주세요: ");
				String marketvalue = Ci.r("시장가치를 입력해주세요: ");
				
				String x = String.format(
						"insert into laliga_squad (p_club,p_number,p_name,p_birth,p_position,p_height,p_foot,p_country,p_market_value,currency) "
								+ "values ('%s','%s','%s','%s','%s','%s','%s','%s','%s','만 유로');"
								,club,backno,name,birth,position,height,foot,country,marketvalue) ;
				dbExecuteUpdate(x);
				System.out.println(x);
				break;
			case "4":	// 명단삭제
				String delclub = Ci.rl("삭제할 선수의 클럽을 입력해주세요(1단계): ");
				String delbackno = Ci.r("삭제할 선수의 등번호를 입력해주세요(2단계): ");
				
				String sql = String.format("delete from laliga_squad where p_club = '%s' and p_number = '%s'",delclub,delbackno);
				System.out.println(sql);
				
				dbExecuteUpdate(sql);
				break;
			case "5":	// 검색
				break;
			case "e":	// 종료
				System.out.println("라리가 스쿼드 종료☜(ﾟヮﾟ☜)");
				break loop;
			}
		}
	}

	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState " + e.getSQLState());
		}
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
			while (result.next()) {
				String name = result.getString("p_name");
				System.out.println(name);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("⚽처리된 명단 수:"+resultCount);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
