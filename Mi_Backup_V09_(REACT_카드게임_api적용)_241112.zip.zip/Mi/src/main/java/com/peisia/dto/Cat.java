package com.peisia.dto;

import java.util.ArrayList;

import lombok.Data;

@Data	
public class Cat {	
	private String name;
	private Integer age;
	public ArrayList<String> hobby = new ArrayList<>();
	public ArrayList<Animal> friends = new ArrayList<>();
	public Cat(String name, Integer age) {
		this.name = name;
		this.age = age;
	}
}	
