package com.peisia.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.peisia.dto.GuestDto;

public interface GuestMapper {
	public int getCount();
	public int getCountSearch(String word);
//	public ArrayList<GuestDto> getList(int limitIndex);
	public ArrayList<GuestDto> getList(int limitIndex);
	public ArrayList<GuestDto> getListSearch(@Param("limitIndex") int limitIndex, @Param("word") String word);
	public GuestDto read(long bno);
	public void del(long bno);
	public void write(GuestDto dto);
	public void modify(GuestDto dto);

}
