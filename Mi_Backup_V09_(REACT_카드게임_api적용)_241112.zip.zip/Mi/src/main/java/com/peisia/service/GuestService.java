package com.peisia.service;

import com.peisia.dto.GuestDto;


public interface GuestService {
//	public ArrayList<GuestDto> getList(int currentPage);
//	public Model getList(Model m, int currentPage);
	public BoardListProcessor getList(int currentPage);
	public GuestDto read(long bno);
	public void del(long bno);
	public void write(GuestDto dto);
	public void modify(GuestDto dto);
	
}
