package com.peisia.dto;

import lombok.Data;

@Data
public class MemberDto {
	
	public java.lang.String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPw() {
		// TODO Auto-generated method stub
		return null;
	} 
}
