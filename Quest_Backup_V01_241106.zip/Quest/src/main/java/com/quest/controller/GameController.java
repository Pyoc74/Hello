package com.quest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.quest.service.GameServiceImpl;

import lombok.Setter;

@RequestMapping("/game")
@Controller
public class GameController {

	@Setter(onMethod_ = @Autowired)
	private GameServiceImpl service;
	
	
//	@Setter(onMethod_ = @Autowired)
//	private GameService service;
	
	@GetMapping("/lobby")
	public void lobby(Model m) {
		System.out.println("==== 컨트롤러 - 게임 - 진입완료");
		
		int n = service.getCharacters();
		
		m.addAttribute("xxx",n);
	}
}
