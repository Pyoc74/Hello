package com.quest.dto;

import lombok.Data;

@Data
public class GameDto {
	private String owner_id;
	private String str_data;
}