package com.quest.mapper;


public interface GameMapper {
	public int getCharacters();
}