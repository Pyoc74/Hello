package com.quest.service;

public interface GameService {
	void getCharacters();	
}
