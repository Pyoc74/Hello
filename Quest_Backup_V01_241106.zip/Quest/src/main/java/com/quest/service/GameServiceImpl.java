package com.quest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quest.mapper.GameMapper;

import lombok.Setter;

@Service
// public class GameServiceImpl implements GameService {
public class GameServiceImpl {

		@Setter(onMethod_ = @Autowired)
		private GameMapper mapper;
	
//		@Override
		public int getCharacters() {
			int n = mapper.getCharacters();
			System.out.println("==== 캐릭터 정보를 불러왔습니다"+n+"개");
			
			return n ;
		}
	
}
